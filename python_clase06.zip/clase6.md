---
jupyter:
  jupytext:
    formats: md,ipynb
    text_representation:
      extension: .md
      format_name: markdown
      format_version: '1.3'
      jupytext_version: 1.13.5
  kernelspec:
    display_name: Python 3 (ipykernel)
    language: python
    name: python3
---

## In case of doing performance tests.
## <font color='red'> CONNECT TO POWER SOURCE if you are using a LAPTOP</font>

```python
import numpy as np

def getUb( n ):
    U = np.triu( np.random.rand(n,n) - 0.5, 1) + np.diag( np.arange(1,n+1) )
    b = np.ones( n )
    return U, b
```

```python

```

```python
n = 4
U,b = getUb(n)
print(U)
print(b)
```

```python
def solveUrow( U, b ):
    m,n = U.shape
    m2  = len(b)
    assert( m==m2 and m==n ), 'system and right-hand-side not compatible.'
    
    # x = b # entonces cuando cambias x cambias b
    x = b.copy()
    for i in reversed( range(n) ):
        for j in range(i+1, n):
            #x[i] = x[i] - x[j]*U[i,j]
            x[i] -= x[j]*U[i,j]
        #x[i] = x[i]/U[i,i]
        x[i] /= U[i,i]
    
    return x
    
```

```python
def solveUrow_v( U, b ):
    m,n = U.shape
    m2  = len(b)
    assert( m==m2 and m==n ), 'system and right-hand-side not compatible.'
    
    # x = b # entonces cuando cambias x cambias b
    x = b.copy()
    for i in reversed( range(n) ):
        x[i] = x[i] - np.dot(x[i+1:], U[i,i+1:])
        #x[i] -= x[j]*U[i,j]
        #x[i] = x[i]/U[i,i]
        x[i] /= U[i,i]
    
    return x
    
```

```python
import numpy.linalg as LA
n = 10
U, b = getUb( n )
x   = LA.solve( U, b )
xap = solveUrow_v( U, b )

x, x-xap
```

```python
list( reversed( range(6) ) )
```

```python

```
