---
jupyter:
  jupytext:
    formats: ipynb,md
    text_representation:
      extension: .md
      format_name: markdown
      format_version: '1.3'
      jupytext_version: 1.13.5
  kernelspec:
    display_name: Python 3 (ipykernel)
    language: python
    name: python3
---

## Prerequisites:
* To see the "get help notebook" click: [get Help](00_getHelp.ipynb) 






# 02a: Operations with vectors and matrices as arrays

<!-- #region -->
Usamos  arrays  en lugar de  numpy.matrix.
##### La razón es:
Manual: https://numpy.org/doc/stable/reference/generated/numpy.matrix.html


It is <font color='red'>NO</font> longer recommended to use the class (numpy.matrix), even for linear algebra.
<br />
Instead use regular arrays. The class <font color='red'>may be removed</font> in the future.
<!-- #endregion -->

```python
# define a variable
v = 4
```

```python
# show value of variable v
v
print('v= ', v)
```

###### Allow to define arrays, and much more.

```python
import numpy as np
```

Define two matrices and show them

```python
A = np.array([[0,2],[3,0]]) # row-by-row
B = np.eye(2)
A, B
```

Multiply two matrices (entry by entry)

```python
A * B
```

Multiply two matrices (as in mathematics)

```python
A @ B,  np.dot(A,B)
```

Extract first row:

```python
A[0,:], A[0]
```

define arrays (which can be interpreted as both row and column vectors)

```python
v = np.array( [ 1,2 ] )
v, v.shape
```

calculate products  v @ B  and  B @ v\
NOTE: NO error because a one-dimensional array is interpreted as both column and row vector

```python
v@A, A@v, (A@v).shape
```

Reproduce mathematical notation and consistency

```python
col = np.array( [ [1] , [2] ] ) # un vector columna
row = np.array( [[ 1,2 ]] )     # un vector renglon
col, row, col.shape, row.shape
```

 Newaxis (reduce brackets)

```python
col = np.array([1,2,3,4])[:,np.newaxis] # un vector columna
row = np.array([1,2,3,4])[np.newaxis,:] # un vector renglon

col, row, col.shape, row.shape
```

Multiplying matrix @ column vector

```python
col = np.array( [ [1] , [2] ] ) # un vector columna
row = np.array( [[ 1,2 ]] )     # un vector renglon
B@col, np.dot(B,col), (B@col).shape
```

Multiplying  row vector @ matrix 

```python
row@A, np.dot(row, A), (row@A).shape
```

Try multiplying  column vector @ matrix (MATHEMATICALLY NOT DEFINED, two ways @ and numpy.dot)

```python
col @ B
```

```python
np.dot(col, B)
```

you can transpose, e.g.

```python
A, A.T, col, col.T.shape
```

With the transpose we can avoid row vectors, for instance

```python
B@col, col.T@A
```

 ATTENTION: the standard multiplication operator * is extended to arrays
 This may give unexpected results, e.g.

```python
row*B*col  # not a real number
```

but, with the operator @ (instead of *), we get the correct result
(but anoying dimensions)

```python
val = row @ B @ col
print(val, val.shape, val[0,0], float(val))
print(row)
print(row[0,:])
print(row[0])
print(col)
print(col[:,0])
#print(col[0]) % mal
print( row[0,:]@B@col[:,0] )
#col[:,0].shape
```

```python
B, col, B*col # not a vector (python automatic extension)
```

```python
A*row # mathematically not defined, but no error.
```

```python
# but, a the mathematatical operation cannot be performed, e.g.
A@row
```

```python
# define a small matrix 3x4, each row goes in like an array.
W = np.array([[3,4,-1, 0],[2,1,3.5,-3],[1,2,1,4]])
#W, 
print(W)
```

```python
# the shape of an array
print(W.shape)                  # 2-dim. array
print(np.array([1,2,3]).shape)  # 1-Dim. array
```

```python
# define a matrix and get the second column and the third row
# note: python starts counting with 0
# note: the shape of an extracted column has only one entry and transposition has no effect.
#       Therefore, the result is flexible in a @-operation, i.e., it can be used as column or row vector.
C = np.diag([1,2,3,4])
C, C[:,1], C[:,1].shape, C[:,1].T, C[2,:], C[2,:].shape
```

```python
# if you desperately want a column
np.array( [ C[:,1] ] ).T
#C[:,1][:,np.newaxis]   # tambien funciona, pero es menos leible.
```

```python
# define matrices of zeros and ones
zs = np.zeros([8,7])
# change an element
zs[6,1] = 4  # renglon 7, col.2, valor 4
# overwrite a part of the matrix
zs[1:4,2:6] = W
zs, zs.shape
```

```python
# an identity matrix
np.eye(5)
```

```python
# ones
os = np.ones((6,9))
os
```

```python
# extract lower-triangular part, 0 with diagonal, -1 without diagonal, -2, without first subdiagonal
np.tril(os, -1)
```

```python
# extract upper-triangular part, 0 with diagonal, 1 without diagonal, 2, without first superdiagonal
np.triu(os,1)
```

```python
np.vstack( (np.ones((1,5)), np.zeros((1,5))) )
#np.array( [np.ones((1,5)), np.zeros((1,5))] ).shape  # en python esto causa 3 dimensiones, en matlab da una matriz
```

```python
np.vstack( (np.ones(5), np.zeros(5)) )
```

```python
np.hstack( (np.ones(5), np.zeros(5)) )
```

```python

```
